import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000"

st.title("💡 Gadgets Dashboard")

try:
    response = requests.get(f"{API_URL}/devices", timeout=3)
    response.raise_for_status()
    devices = response.json()
except requests.exceptions.RequestException as e:
    st.error(f"Impossible de se connecter au backend : {e}")
    st.stop()

for device in devices:
    st.subheader(device['name'])
    led_emoji = "💡" if device['led'] == "ON" else "❌"
    buzzer_emoji = "🔔" if device['buzzer'] == "ON" else "❌"
    
    st.write(f"LED: {led_emoji}  |  Buzzer: {buzzer_emoji}")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button(f"Allumer LED {device['id']}"):
            requests.post(f"{API_URL}/devices/{device['id']}/action", json={"led": "ON"})
            st.session_state['update'] = True
    with col2:
        if st.button(f"Éteindre LED {device['id']}"):
            requests.post(f"{API_URL}/devices/{device['id']}/action", json={"led": "OFF"})
            st.session_state['update'] = True
    with col3:
        if st.button(f"Allumer Buzzer {device['id']}"):
            requests.post(f"{API_URL}/devices/{device['id']}/action", json={"buzzer": "ON"})
            st.session_state['update'] = True
    with col4:
        if st.button(f"Éteindre Buzzer {device['id']}"):
            requests.post(f"{API_URL}/devices/{device['id']}/action", json={"buzzer": "OFF"})
            st.session_state['update'] = True

# Forcer le rafraîchissement si update
if st.session_state.get('update', False):
    st.session_state['update'] = False
    st.experimental_rerun()
