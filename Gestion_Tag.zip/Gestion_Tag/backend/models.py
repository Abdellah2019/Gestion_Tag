from sqlalchemy import Column, Integer, String, Text
from database import Base
import json

class Device(Base):
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    data = Column(Text, default="{}")  # Stocke les infos en JSON

    def get_data(self):
        return json.loads(self.data)

    def set_data(self, data_dict):
        self.data = json.dumps(data_dict)

