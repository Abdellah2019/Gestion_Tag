from .database import Base, engine, SessionLocal
from .models import Device

Base.metadata.create_all(bind=engine)
db = SessionLocal()

if not db.query(Device).all():
    d1 = Device(name="Appareil 1", data='{"led":"OFF","buzzer":"OFF"}')
    d2 = Device(name="Appareil 2", data='{"led":"OFF","buzzer":"OFF"}')
    db.add_all([d1, d2])
    db.commit()

db.close()
print("Base initialisée ✅")
