from flask import Flask, render_template, request, redirect, jsonify
from database import Base, engine, SessionLocal
from models import Device
import json

app = Flask(__name__)

# Crée la BDD si pas encore existante
Base.metadata.create_all(bind=engine)

@app.route("/")
def index():
    db = SessionLocal()
    devices = db.query(Device).all()
    db.close()
    return render_template("index.html", devices=devices)

@app.route("/device/<int:device_id>")
def device_detail(device_id):
    db = SessionLocal()
    device = db.query(Device).get(device_id)
    device_dict=device.get_data()
    db.close()
    return render_template("device.html", device=device, device_data=device_dict)

@app.route("/device/<int:device_id>/action", methods=["POST"])
def toggle_action(device_id):
    component = request.form.get("component")
    db = SessionLocal()
    device = db.query(Device).get(device_id)
    data = device.get_data()
    if component in data:
        data[component] = "OFF" if data[component] == "ON" else "ON"
    device.set_data(data)
    db.commit()
    db.close()
    return redirect(f"/device/{device_id}")

@app.route("/device/<int:device_id>/update_full", methods=["POST"])
def update_device(device_id):
    db = SessionLocal()
    device = db.query(Device).get(device_id)
    new_data = request.get_json().get("data", {})  # <-- utiliser get_json()
    data = device.get_data()

    # Conserve LED et Buzzer
    if "led" in data:
        new_data["led"] = data["led"]
    if "buzzer" in data:
        new_data["buzzer"] = data["buzzer"]

    device.set_data(new_data)
    db.commit()
    db.close()
    return jsonify({"status": "ok"})

# ----------------------------
# ROUTE AJOUTER UN DEVICE
# ----------------------------
@app.route("/device/add", methods=["POST"])
def add_device():
    db = SessionLocal()
    content = request.get_json()  # <- Important pour récupérer le JSON
    name = content.get("name", "Sans Nom")
    data = content.get("data", {"led": "OFF", "buzzer": "OFF"})

    new_device = Device(name=name)
    new_device.set_data(data)

    db.add(new_device)
    db.commit()
    db.close()
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000,debug=True)
