from models import Device, Action

# Base de données simulée
DEVICES = {
    "1": Device(id="1", name="Gadget 1", data={"info": "Capteur température", "led": "OFF", "buzzer": "OFF"}),
    "2": Device(id="2", name="Gadget 2", data={"info": "Détecteur mouvement", "led": "OFF", "buzzer": "OFF"})
}

def get_all_devices():
    return list(DEVICES.values())

def get_device(device_id: str):
    return DEVICES.get(device_id)

def toggle_device(device_id: str, component: str):
    device = DEVICES.get(device_id)
    if not device:
        return None
    if component in device.data:
        device.data[component] = "OFF" if device.data[component] == "ON" else "ON"
    return device